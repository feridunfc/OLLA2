# MULTI-AI v4.8 Roadmap (Sprint 1–4)
- Sprint 1: Critic Agent + Auto Patch + Patch Ledger
- Sprint 2: Policy Agent + Budget Guard + Hybrid Routing
- Sprint 3: Secure Sandbox (Docker) + Human Approval in Bash tool
- Sprint 4: Observability (Prometheus /metrics) + Business Metrics
