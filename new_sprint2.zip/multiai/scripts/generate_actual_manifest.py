# generate_actual_manifest.py
