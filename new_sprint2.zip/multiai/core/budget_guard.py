# multiai/core/budget_guard.py
import logging
import os
from typing import Dict

class BudgetGuard:
    """Minimal deterministic budget control for Sprint-0"""

    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.spent = 0.0
        self.daily_limit = float(os.getenv("DAILY_BUDGET_LIMIT", "10.0"))

    def can_spend(self, estimated_cost: float) -> bool:
        """Check if spending is allowed."""
        # Sprint-0 fallback: allow spending if providers are configured
        if os.getenv("LLM_PROVIDERS_READY") != "1":
            self.logger.warning("BudgetGuard: providers not configured, blocking spend")
            return False

        if (self.spent + estimated_cost) > self.daily_limit:
            self.logger.error("BudgetGuard: budget exceeded")
            return False

        return True

    def record_spending(self, provider: str, cost: float):
        """Record spending event"""
        self.spent += cost
        self.logger.info(f"BudgetGuard: recorded {cost:.4f} from {provider}. Total={self.spent:.4f}")

    def get_status(self) -> Dict[str, float]:
        return {"spent": self.spent, "daily_limit": self.daily_limit}
