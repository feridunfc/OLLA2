import LedgerDashboard from "./LedgerDashboard";
export default function App() {
  return <LedgerDashboard />;
}
