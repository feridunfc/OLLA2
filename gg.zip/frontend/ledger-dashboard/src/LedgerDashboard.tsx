import { useEffect, useState } from "react";
import { Loader2, RefreshCw } from "lucide-react";

export default function LedgerDashboard() {
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function fetchEntries() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("http://127.0.0.1:8000/api/ledger/entries");
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setEntries(data.entries || []);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchEntries();
  }, []);

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Sprint Ledger Viewer</h1>
        <button
          onClick={fetchEntries}
          disabled={loading}
          className="flex items-center bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg"
        >
          {loading ? (
            <Loader2 className="animate-spin w-4 h-4 mr-2" />
          ) : (
            <RefreshCw className="w-4 h-4 mr-2" />
          )}
          Refresh
        </button>
      </div>

      {error && <div className="text-red-500">⚠️ {error}</div>}

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {entries.length === 0 && !loading && (
          <p className="text-gray-500">No ledger entries found.</p>
        )}

        {entries.map((entry: any) => (
          <div
            key={entry.id}
            className="bg-white shadow-md rounded-xl p-4 space-y-2 hover:shadow-lg transition"
          >
            <div className="flex justify-between text-sm font-semibold">
              <span>Sprint:</span>
              <span>{entry.sprint_id}</span>
            </div>
            <div className="text-xs text-gray-600 break-all">
              <strong>Hash:</strong> {entry.manifest_hash}
            </div>
            <div className="text-xs text-gray-600 break-all">
              <strong>Signature:</strong> {entry.signature}
            </div>
            <div className="text-xs text-gray-500">
              <strong>Timestamp:</strong>{" "}
              {new Date(entry.timestamp * 1000).toLocaleString()}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
