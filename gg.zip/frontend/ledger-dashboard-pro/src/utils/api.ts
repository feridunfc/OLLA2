export const API_BASE =
  process.env.REACT_APP_API_BASE || "http://127.0.0.1:8000";

export type LedgerEntry = {
  id: number;
  timestamp: number;
  sprint_id: string;
  manifest_hash: string;
  signature: string;
};

export type LedgerEntriesResponse = {
  entries: LedgerEntry[];
  total: number;
};

export async function fetchEntries(): Promise<LedgerEntriesResponse> {
  const res = await fetch(`${API_BASE}/api/ledger/entries`, {
    headers: { "Content-Type": "application/json" },
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

export async function verifyEntry(ledgerId: number) {
  const res = await fetch(`${API_BASE}/api/ledger/verify/${ledgerId}`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}
