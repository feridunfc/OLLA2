import { LedgerEntry } from "../utils/api";

type Props = { data: LedgerEntry[]; onVerify: (id: number) => void };

export default function LedgerTable({ data, onVerify }: Props) {
  if (data.length === 0) {
    return <div className="text-center text-slate-300 mt-10">No ledger entries found.</div>;
  }
  return (
    <div className="overflow-hidden rounded-xl border border-slate-700/50">
      <table className="min-w-full bg-slate-900/40">
        <thead className="bg-slate-800/60">
          <tr className="text-left text-slate-300">
            <th className="px-4 py-3">ID</th>
            <th className="px-4 py-3">Sprint</th>
            <th className="px-4 py-3">Hash</th>
            <th className="px-4 py-3">Signature</th>
            <th className="px-4 py-3">Timestamp</th>
            <th className="px-4 py-3"></th>
          </tr>
        </thead>
        <tbody>
          {data.map((e) => (
            <tr key={e.id} className="border-t border-slate-800/60">
              <td className="px-4 py-3 font-mono text-sm text-slate-200">{e.id}</td>
              <td className="px-4 py-3">{e.sprint_id}</td>
              <td className="px-4 py-3 font-mono text-xs"><span title={e.manifest_hash}>{e.manifest_hash.slice(0, 10)}…</span></td>
              <td className="px-4 py-3 font-mono text-xs"><span title={e.signature}>{e.signature.slice(0, 12)}…</span></td>
              <td className="px-4 py-3">{new Date(e.timestamp * 1000).toLocaleString()}</td>
              <td className="px-4 py-3">
                <button onClick={() => onVerify(e.id)} className="px-2 py-1 rounded bg-indigo-600 hover:bg-indigo-500 text-sm">Verify</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
