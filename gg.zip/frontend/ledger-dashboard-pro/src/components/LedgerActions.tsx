import { saveAs } from "file-saver";
import { jsPDF } from "jspdf";
import { LedgerEntry } from "../utils/api";
import { toast } from "react-toastify";

type Props = { data: LedgerEntry[]; onRefresh: () => void; onVerify: (id: number) => Promise<void>; };

function toCSV(rows: LedgerEntry[]): string {
  const header = ["id","timestamp","sprint_id","manifest_hash","signature"];
  const lines = [header.join(","), ...rows.map(r=>[r.id,r.timestamp,JSON.stringify(r.sprint_id),r.manifest_hash,r.signature].join(","))];
  return lines.join("\n");
}

export default function LedgerActions({ data, onRefresh, onVerify }: Props) {
  const handleCSV = () => {
    const content = toCSV(data);
    const blob = new Blob([content], { type: "text/csv;charset=utf-8" });
    saveAs(blob, "ledger-entries.csv");
    toast.success("CSV exported");
  };

  const handlePDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(12);
    doc.text("Ledger Entries", 14, 14);
    let y = 24;
    const maxWidth = 180;
    data.slice(0,25).forEach(e => {
      const block = [
        `#${e.id}  Sprint: ${e.sprint_id}`,
        `Hash: ${e.manifest_hash}`,
        `Signature: ${e.signature.slice(0, 36)}...`,
        `Time: ${new Date(e.timestamp*1000).toLocaleString()}`
      ];
      block.forEach(line => { const split = doc.splitTextToSize(line, maxWidth); doc.text(split, 14, y); y += 6*split.length; });
      y += 4;
      if (y > 280) { doc.addPage(); y = 20; }
    });
    doc.save("ledger-entries.pdf");
    toast.success("PDF exported");
  };

  return (
    <div className="flex items-center gap-2">
      <button onClick={onRefresh} className="px-3 py-2 rounded-md bg-blue-600 hover:bg-blue-500 transition">Refresh</button>
      <button onClick={handleCSV} className="px-3 py-2 rounded-md bg-emerald-600 hover:bg-emerald-500 transition">Export CSV</button>
      <button onClick={handlePDF} className="px-3 py-2 rounded-md bg-fuchsia-600 hover:bg-fuchsia-500 transition">Export PDF</button>
    </div>
  );
}
