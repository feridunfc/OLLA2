import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from "recharts";
import { LedgerEntry } from "../utils/api";
type Props = { data: LedgerEntry[] };
export default function LedgerChart({ data }: Props) {
  const chartData = data.slice().reverse().map((e) => ({
    name: `#${e.id}`, value: 1, ts: e.timestamp,
  }));
  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={chartData}>
          <XAxis dataKey="name" stroke="#9FB3C8" />
          <YAxis stroke="#9FB3C8" />
          <Tooltip />
          <Bar dataKey="value" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
