import { useEffect, useMemo, useState } from "react";
import Toast from "./components/Toast";
import LedgerTable from "./components/LedgerTable";
import LedgerChart from "./components/LedgerChart";
import LedgerActions from "./components/LedgerActions";
import { fetchEntries, verifyEntry, LedgerEntry } from "./utils/api";
import { toast } from "react-toastify";

export default function App() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [entries, setEntries] = useState<LedgerEntry[]>([]);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchEntries();
      setEntries(data.entries ?? []);
      if ((data.entries ?? []).length === 0) toast.info("No ledger entries yet");
      else toast.success(`Loaded ${data.entries.length} entries`);
    } catch (e: any) {
      setError(e?.message || "Fetch failed");
      toast.error(`Fetch failed: ${e?.message || "unknown"}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const total = entries.length;
  const lastTs = useMemo(
    () => (entries[0]?.timestamp ? new Date(entries[0].timestamp * 1000).toLocaleString() : "-"),
    [entries]
  );

  const handleVerify = async (id: number) => {
    try {
      const res = await verifyEntry(id);
      if (res.valid) toast.success(`Signature valid for #${id}`);
      else toast.error(`Signature invalid for #${id}`);
    } catch (e: any) {
      toast.error(`Verification error: ${e?.message || "unknown"}`);
    }
  };

  return (
    <div className="min-h-screen p-6 md:p-10">
      <div className="max-w-6xl mx-auto space-y-6">
        <header className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">Sprint Ledger Viewer · Pro</h1>
            <p className="text-slate-300/80 mt-1">
              {loading ? "Loading…" : error ? <span className='text-rose-300'>Failed to fetch</span> : "Ready"} ·{" "}
              <span className="text-slate-400">Total:</span> {total} ·{" "}
              <span className="text-slate-400">Last:</span> {lastTs}
            </p>
          </div>
          <LedgerActions data={entries} onRefresh={load} onVerify={handleVerify} />
        </header>

        <section className="grid md:grid-cols-5 gap-6">
          <div className="md:col-span-3 bg-[#111732] rounded-2xl p-4 border border-slate-700/50 shadow-lg shadow-black/30">
            <h2 className="text-lg font-medium mb-3">Recent Entries</h2>
            <LedgerTable data={entries} onVerify={handleVerify} />
          </div>
          <div className="md:col-span-2 bg-[#111732] rounded-2xl p-4 border border-slate-700/50 shadow-lg shadow-black/30">
            <h2 className="text-lg font-medium mb-3">Activity</h2>
            <LedgerChart data={entries} />
          </div>
        </section>
      </div>
      <Toast />
    </div>
  );
}
