# Ledger Dashboard Pro

Simple, nice React + Tailwind + Recharts dashboard for MULTIAI ledger.

## Setup

```powershell
cd frontend\ledger-dashboard-pro
copy .env.sample .env
# edit .env if your API is NOT at http://127.0.0.1:8000
npm install
npm start
```

The app calls: `GET %REACT_APP_API_BASE%/api/ledger/entries` and `GET %REACT_APP_API_BASE%/api/ledger/verify/:id`.
