# compare_manifest.py
