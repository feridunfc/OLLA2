# FastAPI metrics middleware
